from flask import Flask, request, jsonify, send_file, render_template
import os
from flask_cors import CORS
import ffmpeg
from gtts import gTTS
import speech_recognition as sr
from deep_translator import GoogleTranslator
import time

# Path to ffmpeg executable
FFMPEG_PATH = r"C:\Users\Aadityaamlan Panda\Downloads\ffmpeg-7.1-essentials_build\ffmpeg-7.1-essentials_build\bin\ffmpeg.exe"
FFPROBE_PATH = r"C:\Users\Aadityaamlan Panda\Downloads\ffmpeg-7.1-essentials_build\ffmpeg-7.1-essentials_build\bin\ffprobe.exe"


app = Flask(__name__)
CORS(app)

# Temporary folder for storing intermediate files
TEMP_FOLDER = "temp/"
os.makedirs(TEMP_FOLDER, exist_ok=True)

@app.route("/")
def index():
    return render_template("index.html")

# Utility Functions
def extract_audio(video_path, audio_path):
    """Extracts audio from a video file."""
    print(f"Extracting audio from: {video_path} to: {audio_path}")
    try:
        ffmpeg.input(video_path).output(audio_path, format="wav").run(cmd=FFMPEG_PATH, overwrite_output=True)
        print(f"Audio extracted successfully: {audio_path}")
    except Exception as e:
        print(f"Error extracting audio: {e}")
        raise ValueError(f"Error extracting audio: {str(e)}")

def speech_to_text(audio_path):
    """Converts audio to text using Google Speech Recognition."""
    print(f"Converting audio to text: {audio_path}")
    recognizer = sr.Recognizer()
    try:
        with sr.AudioFile(audio_path) as source:
            audio = recognizer.record(source)
        transcript = recognizer.recognize_google(audio)
        print(f"Transcript obtained: {transcript}")
        return transcript
    except sr.UnknownValueError:
        print("Could not understand the audio.")
        raise ValueError("Could not understand the audio.")
    except sr.RequestError as e:
        print(f"Google Speech Recognition error: {e}")
        raise ValueError(f"Google Speech Recognition error: {e}")
    except Exception as e:
        print(f"Speech-to-text error: {e}")
        raise ValueError(f"Speech-to-text error: {str(e)}")

def translate_text(text, src_lang="auto", target_lang="hi"):
    """Translates text using the Deep Translator library."""
    print(f"Translating text: '{text}' from {src_lang} to {target_lang}")
    try:
        translated_text = GoogleTranslator(source=src_lang, target=target_lang).translate(text)
        print(f"Translated text: {translated_text}")
        return translated_text
    except Exception as e:
        print(f"Translation error: {e}")
        raise ValueError(f"Translation error: {str(e)}")

def text_to_speech(text, output_audio_path, lang="hi"):
    """Generates speech audio from text using gTTS."""
    print(f"Generating speech for text: '{text}' in language: {lang}")
    try:
        tts = gTTS(text=text, lang=lang)
        tts.save(output_audio_path)
        print(f"Speech generated and saved at: {output_audio_path}")
    except Exception as e:
        print(f"Text-to-speech error: {e}")
        raise ValueError(f"Text-to-speech error: {str(e)}")

def merge_audio_with_video(video_path, audio_path, output_path):
    """Merges translated audio with the original video, replacing the original audio."""
    print(f"Merging translated audio: {audio_path} with video: {video_path}")
    try:
        # Load video and translated audio inputs
        video_input = ffmpeg.input(video_path)
        audio_input = ffmpeg.input(audio_path)

        # Combine video and translated audio, discarding the original audio
        ffmpeg.output(
            video_input.video,  # Use the video stream only
            audio_input.audio,  # Use the translated audio stream
            output_path,
            vcodec="copy",  # Copy the video stream without re-encoding
            acodec="aac",   # Encode the audio stream in AAC format
            strict="experimental"  # Enable experimental codecs if required
        ).run(cmd=FFMPEG_PATH, overwrite_output=True)
        print(f"Audio and video merged successfully. Output path: {output_path}")
    except Exception as e:
        print(f"Error merging audio and video: {e}")
        raise ValueError(f"Error merging audio and video: {str(e)}")

# New utility function to split video into 60-second segments using FFmpeg
def split_video(video_path, segment_duration=60):
    """Splits the video into 60-second segments."""
    print(f"Splitting video {video_path} into {segment_duration}-second segments.")
    try:
        # Get the duration of the video
        probe = ffmpeg.probe(video_path, v='error', select_streams='v:0', show_entries='format=duration', cmd=FFPROBE_PATH)
        duration = float(probe['format']['duration'])
        
        # Split video into segments
        segments = []
        for i in range(0, int(duration), segment_duration):
            segment_output = os.path.join(TEMP_FOLDER, f"segment_{i // segment_duration + 1}.mp4")
            ffmpeg.input(video_path, ss=i, t=segment_duration).output(segment_output).run(cmd=FFMPEG_PATH, overwrite_output=True)
            segments.append(segment_output)
        
        print(f"Video split into {len(segments)} segments.")
        return segments
    except Exception as e:
        print(f"Error splitting video: {e}")
        raise ValueError(f"Error splitting video: {str(e)}")


def combine_video_segments(segment_files, output_video_path):
    """Combines video segments into one final video using concat demuxer."""
    try:
        # Create the file list for the concat demuxer
        file_list_path = os.path.join(TEMP_FOLDER, "filelist.txt")

        with open(file_list_path, "w") as file:
            for segment in segment_files:
                # Ensure to use absolute paths
                abs_path = os.path.abspath(segment)  # Get absolute path of segment
                file.write(f"file '{abs_path}'\n")  # Write absolute path to the file

        # Concatenate using the concat demuxer
        ffmpeg.input(file_list_path, format='concat', safe=0).output(output_video_path, c='copy').run(cmd=FFMPEG_PATH, overwrite_output=True)

        print(f"Video segments successfully combined into: {output_video_path}")
    except Exception as e:
        print(f"Error combining video segments: {e}")
        raise ValueError(f"Error combining video segments: {str(e)}")



# API Endpoints
@app.route("/dub", methods=["POST"])
def dub_video():
    """Handles video dubbing requests."""
    try:
        # Save video file
        video_file = request.files["video"]
        video_path = os.path.join(TEMP_FOLDER, video_file.filename)
        print(f"Received video for dubbing: {video_path}")
        video_file.save(video_path)

        # Split the video into 60-second segments
        video_segments = split_video(video_path)

        # Intermediate file paths for dubbed segments
        dubbed_segments = []

        # Process each segment
        for idx, segment_path in enumerate(video_segments):
            # Extract audio from segment
            audio_path = os.path.join(TEMP_FOLDER, f"{os.path.basename(segment_path)}_audio.wav")
            extract_audio(segment_path, audio_path)

            # Convert audio to text
            original_transcript = speech_to_text(audio_path)

            # Translate text to the target language
            target_lang = request.form.get("target_lang", "hi")
            translated_text = translate_text(original_transcript, target_lang=target_lang)

            # Generate translated speech for the segment
            translated_audio_path = os.path.join(TEMP_FOLDER, f"translated_audio_{idx}.mp3")
            text_to_speech(translated_text, translated_audio_path, lang=target_lang)

            # Merge the translated audio with the video segment
            output_segment_path = os.path.join(TEMP_FOLDER, f"dubbed_segment_{idx}.mp4")
            merge_audio_with_video(segment_path, translated_audio_path, output_segment_path)
            dubbed_segments.append(output_segment_path)

        # Combine all dubbed segments into one final video
        final_video_path = os.path.join(TEMP_FOLDER, "final_dubbed_video.mp4")
        combine_video_segments(dubbed_segments, final_video_path)

        # Return the final dubbed video
        print(f"Dubbing completed successfully. Returning file: {final_video_path}")
        return send_file(final_video_path, as_attachment=True)

    except Exception as e:
        print(f"Dubbing error: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
